﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using AutoMapper;
using CarDealer.Data;
using CarDealer.DTO;
using CarDealer.Models;
using Newtonsoft.Json;

namespace CarDealer
{
    public class StartUp
    {
        static IMapper mapper;
        public static void Main(string[] args)
        {
            //1. Setup Database

            CarDealerContext carDealerContext = new CarDealerContext();
            carDealerContext.Database.EnsureDeleted();
            carDealerContext.Database.EnsureCreated();

            string inputJsonSuppliers = File.ReadAllText("../../../Datasets/suppliers.json");
            string resultProblem09 = ImportSuppliers(carDealerContext, inputJsonSuppliers);
            Console.WriteLine(resultProblem09);



        }

        //2.Import Data

        //Query 9. Import Suppliers

        public static string ImportSuppliers(CarDealerContext context, string inputJson)
        {
            IntializeAutoMapper();

            IEnumerable<SupplierInputModel> dtoSuppliers = JsonConvert.DeserializeObject<IEnumerable<SupplierInputModel>>(inputJson);

            IEnumerable<Supplier> suppliers = mapper.Map<IEnumerable<Supplier>>(dtoSuppliers);

            context.Suppliers.AddRange(suppliers);
            context.SaveChanges();

            return $"Successfully imported {suppliers.Count()}.";

        }

        private static void IntializeAutoMapper()
        {
            MapperConfiguration config = new MapperConfiguration(cfg => cfg.AddProfile<CarDealerProfile>());
            mapper = config.CreateMapper();
        }
    }
}